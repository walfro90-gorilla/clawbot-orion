// ─────────────────────────────────────────────────────────────────────────────
// Orion Sync — Content Script
//
// Inyectado en cada página de linkedin.com. Su trabajo:
//   1. Escuchar comandos del background service worker
//   2. Ejecutar la acción DOM correspondiente (click connect, fill note, etc.)
//   3. Reportar resultado al background
//
// Importante: este script vive en el mundo "isolated" del content script.
// No tiene acceso directo a `window` de la página. Para interactuar con
// scripts de LinkedIn (ej. para leer Voyager API), usaríamos chrome.scripting.
// ─────────────────────────────────────────────────────────────────────────────

console.log('[Orion content] Loaded on', window.location.href)

// ── Listener de comandos del background ─────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type !== 'orion_command') return false

  const { commandId, action, payload } = msg
  console.log(`[Orion content] Command ${action} (${commandId})`, payload)

  // Ejecutar de forma asíncrona y responder
  executeAction(action, payload)
    .then(result => sendResponse({ ok: true, ...result }))
    .catch(err => sendResponse({ ok: false, error: err.message ?? String(err) }))

  return true  // mantener canal abierto para sendResponse asíncrono
})

// ── Acciones disponibles ────────────────────────────────────────────────────

async function executeAction(action, payload) {
  switch (action) {
    case 'check_inbox':
      return await checkInbox(payload)
    case 'send_invite':
      return await sendInvite(payload)
    case 'send_followup':
      return await sendFollowup(payload)
    case 'search':
      return await searchLeads(payload)
    case 'capture_session':
      return await captureSession()
    default:
      throw new Error(`Unknown action: ${action}`)
  }
}

// ── 2.6 — captura inicial de sesión ─────────────────────────────────────────
// Cuando el usuario instala la extension y se autentica, server pide capture_session.
// El extension lee todas las cookies de linkedin.com + fingerprint y las manda.

async function captureSession() {
  // Cookies se leen en el background con chrome.cookies (mejor permisos)
  // Aquí capturamos el fingerprint del browser real
  return {
    fingerprint: {
      userAgent:       navigator.userAgent,
      platform:        navigator.platform,
      languages:       Array.from(navigator.languages || []),
      locale:          navigator.language,
      viewport:        { width: window.innerWidth, height: window.innerHeight },
      screen:          { width: screen.width, height: screen.height, depth: screen.colorDepth },
      timezone:        Intl.DateTimeFormat().resolvedOptions().timeZone,
      timezoneOffset:  new Date().getTimezoneOffset(),
      deviceMemory:    navigator.deviceMemory,
      hardwareConcurrency: navigator.hardwareConcurrency,
      // WebGL fingerprint (opcional, requiere canvas)
      webgl: getWebGLInfo(),
    },
    capturedAt: new Date().toISOString(),
    currentUrl: window.location.href,
  }
}

function getWebGLInfo() {
  try {
    const canvas = document.createElement('canvas')
    const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl')
    if (!gl) return null
    const dbg = gl.getExtension('WEBGL_debug_renderer_info')
    return {
      vendor:   dbg ? gl.getParameter(dbg.UNMASKED_VENDOR_WEBGL) : null,
      renderer: dbg ? gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL) : null,
    }
  } catch { return null }
}

// ── 2.2 — check_inbox (PENDING, primer comando ejecutable real) ────────────

async function checkInbox(_payload) {
  // STUB: implementar en sub-fase 2.2
  // Tareas:
  //   1. Navegar a /messaging/ (location.href si no estamos ahí)
  //   2. Esperar lista de conversaciones
  //   3. Scrape conversation items (nombre, último mensaje, unread, thread URL)
  //   4. Retornar al server
  return {
    action: 'check_inbox',
    status: 'not_implemented',
    note:   'Pendiente sub-fase 2.2',
  }
}

// ── 2.3 — send_invite (PENDING) ────────────────────────────────────────────

async function sendInvite(_payload) {
  // STUB
  return { action: 'send_invite', status: 'not_implemented', note: 'Pendiente sub-fase 2.3' }
}

// ── 2.4 — send_followup (PENDING) ──────────────────────────────────────────

async function sendFollowup(_payload) {
  // STUB
  return { action: 'send_followup', status: 'not_implemented', note: 'Pendiente sub-fase 2.4' }
}

// ── 2.5 — search (PENDING) ──────────────────────────────────────────────────

async function searchLeads(_payload) {
  // STUB
  return { action: 'search', status: 'not_implemented', note: 'Pendiente sub-fase 2.5' }
}
