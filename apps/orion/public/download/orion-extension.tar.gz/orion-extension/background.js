// ─────────────────────────────────────────────────────────────────────────────
// Orion Sync — Background Service Worker (Manifest V3)
//
// Responsabilidades:
//   1. Mantener WebSocket persistente con Orion server
//   2. Recibir comandos del server (send_invite, check_inbox, send_fu, search)
//   3. Despachar comandos al content script de la tab LinkedIn activa
//   4. Reportar resultados de vuelta al server
//   5. Reconexión automática con backoff exponencial
//
// Importante MV3: este service worker se duerme cuando no hay actividad.
// La WS se restablece al despertar. Por eso usamos alarms para keep-alive.
// ─────────────────────────────────────────────────────────────────────────────

const STORAGE_KEYS = {
  ORION_URL:  'orion_url',     // ej: 'https://app.tuOrion.com' (tu instancia)
  API_KEY:    'orion_api_key', // generada en /dashboard/accounts
  ACTIVE_ACCOUNT_ID: 'active_account_id',
  CONNECTED:  'connected',
}

let ws = null
let reconnectAttempts = 0
let heartbeatInterval = null

// ── Lifecycle ────────────────────────────────────────────────────────────────

self.addEventListener('install', () => {
  console.log('[Orion] Service worker installed')
  self.skipWaiting()
})

self.addEventListener('activate', (event) => {
  console.log('[Orion] Service worker activated')
  event.waitUntil(self.clients.claim())
  // No conectamos automáticamente — esperamos a que el usuario configure API key
  initIfConfigured()
})

// Keep-alive via alarm (MV3 sleeps SW después de 30s idle)
chrome.alarms.create('keep-alive', { periodInMinutes: 0.4 })
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'keep-alive') {
    // Ping al WS para mantener vivo; reconecta si está cerrado
    if (ws && ws.readyState === WebSocket.OPEN) {
      try { ws.send(JSON.stringify({ type: 'ping', ts: Date.now() })) } catch {}
    } else {
      initIfConfigured()
    }
  }
})

// ── Connection management ────────────────────────────────────────────────────

async function initIfConfigured() {
  const { orion_url, orion_api_key, active_account_id } = await chrome.storage.local.get([
    STORAGE_KEYS.ORION_URL,
    STORAGE_KEYS.API_KEY,
    STORAGE_KEYS.ACTIVE_ACCOUNT_ID,
  ])
  if (!orion_url || !orion_api_key || !active_account_id) {
    console.log('[Orion] Not configured — open popup to set API key + account')
    return
  }
  connect(orion_url, orion_api_key, active_account_id)
}

function connect(orionUrl, apiKey, accountId) {
  // Cerrar conexión previa si existe
  if (ws) { try { ws.close() } catch {} ws = null }

  const wsUrl = orionUrl.replace(/^http/, 'ws') + `/api/extension/ws?account=${accountId}`
  console.log(`[Orion] Connecting to ${wsUrl}...`)

  try {
    ws = new WebSocket(wsUrl)
  } catch (err) {
    console.error('[Orion] WS construction failed:', err)
    scheduleReconnect()
    return
  }

  ws.addEventListener('open', () => {
    console.log('[Orion] WS connected')
    reconnectAttempts = 0
    // Auth handshake: enviar API key inmediatamente
    ws.send(JSON.stringify({
      type:       'auth',
      apiKey,
      accountId,
      version:    chrome.runtime.getManifest().version,
      userAgent:  navigator.userAgent,
    }))
    chrome.storage.local.set({ [STORAGE_KEYS.CONNECTED]: true })
    updateBadge('●', '#22c55e') // green dot
  })

  ws.addEventListener('message', async (event) => {
    let msg
    try { msg = JSON.parse(event.data) } catch { return }
    await handleServerMessage(msg)
  })

  ws.addEventListener('close', () => {
    console.log('[Orion] WS closed')
    chrome.storage.local.set({ [STORAGE_KEYS.CONNECTED]: false })
    updateBadge('×', '#ef4444') // red x
    scheduleReconnect()
  })

  ws.addEventListener('error', (err) => {
    console.warn('[Orion] WS error:', err)
    // close handler manejará la reconexión
  })
}

function scheduleReconnect() {
  reconnectAttempts++
  // Backoff exponencial con jitter: 2s → 4s → 8s → 16s → max 60s
  const baseDelay = Math.min(60_000, 2_000 * Math.pow(2, reconnectAttempts - 1))
  const jitter = Math.random() * 1_000
  const delay = baseDelay + jitter
  console.log(`[Orion] Reconnecting in ${(delay/1000).toFixed(1)}s (attempt ${reconnectAttempts})`)
  setTimeout(() => initIfConfigured(), delay)
}

// ── Message handlers ─────────────────────────────────────────────────────────

async function handleServerMessage(msg) {
  console.log('[Orion] Server msg:', msg.type)
  switch (msg.type) {
    case 'auth_ok':
      console.log('[Orion] Authenticated as', msg.accountLabel ?? msg.accountId)
      return
    case 'auth_error':
      console.error('[Orion] Auth failed:', msg.error)
      chrome.storage.local.set({ [STORAGE_KEYS.CONNECTED]: false })
      return
    case 'ping':
      ws.send(JSON.stringify({ type: 'pong', ts: msg.ts }))
      return
    case 'pong':
      // ack del keep-alive
      return
    case 'command':
      await executeCommand(msg.commandId, msg.action, msg.payload)
      return
    default:
      console.warn('[Orion] Unknown msg type:', msg.type)
  }
}

// ── Command dispatcher ──────────────────────────────────────────────────────

async function executeCommand(commandId, action, payload) {
  console.log(`[Orion] Executing ${action} (cmd ${commandId})`, payload)

  // Despachar acción al content script en una tab LinkedIn
  try {
    const tab = await findOrCreateLinkedInTab()
    const result = await chrome.tabs.sendMessage(tab.id, {
      type:    'orion_command',
      commandId,
      action,
      payload,
    })
    reportResult(commandId, action, result)
  } catch (err) {
    console.error(`[Orion] Command failed:`, err)
    reportResult(commandId, action, { ok: false, error: err.message ?? String(err) })
  }
}

async function findOrCreateLinkedInTab() {
  // Buscar tab existente en linkedin.com
  const tabs = await chrome.tabs.query({ url: '*://*.linkedin.com/*' })
  if (tabs.length > 0) {
    // Activar la primera (más reciente)
    return tabs[0]
  }
  // Crear nueva tab si no existe
  return await chrome.tabs.create({ url: 'https://www.linkedin.com/feed/', active: false })
}

function reportResult(commandId, action, result) {
  if (!ws || ws.readyState !== WebSocket.OPEN) return
  ws.send(JSON.stringify({
    type:      'command_result',
    commandId,
    action,
    result,
    ts:        Date.now(),
  }))
}

// ── UI ──────────────────────────────────────────────────────────────────────

function updateBadge(text, color) {
  try {
    chrome.action.setBadgeText({ text })
    chrome.action.setBadgeBackgroundColor({ color })
  } catch {}
}

// ── Listener para popup ─────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'reconnect') {
    initIfConfigured()
    sendResponse({ ok: true })
    return true
  }
  if (msg.type === 'get_status') {
    sendResponse({
      connected: ws && ws.readyState === WebSocket.OPEN,
      reconnectAttempts,
    })
    return true
  }
  if (msg.type === 'disconnect') {
    if (ws) { try { ws.close() } catch {} ws = null }
    chrome.storage.local.set({ [STORAGE_KEYS.CONNECTED]: false })
    sendResponse({ ok: true })
    return true
  }
  return false
})
