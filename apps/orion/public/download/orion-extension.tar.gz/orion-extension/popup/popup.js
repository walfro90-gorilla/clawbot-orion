// Popup script — UI para configurar API key + cuenta + reconectar

const STORAGE_KEYS = {
  ORION_URL: 'orion_url',
  API_KEY:   'orion_api_key',
  ACTIVE_ACCOUNT_ID: 'active_account_id',
  CONNECTED: 'connected',
}

const $url      = document.getElementById('orion-url')
const $apiKey   = document.getElementById('api-key')
const $account  = document.getElementById('account-id')
const $connect  = document.getElementById('connect-btn')
const $disconnect = document.getElementById('disconnect-btn')
const $statusDot  = document.getElementById('status-dot')
const $statusText = document.getElementById('status-text')

// ── Cargar valores guardados ───────────────────────────────────────────────

async function loadStored() {
  const stored = await chrome.storage.local.get([
    STORAGE_KEYS.ORION_URL,
    STORAGE_KEYS.API_KEY,
    STORAGE_KEYS.ACTIVE_ACCOUNT_ID,
  ])
  if (stored.orion_url)         $url.value     = stored.orion_url
  if (stored.orion_api_key)     $apiKey.value  = stored.orion_api_key
  if (stored.active_account_id) $account.value = stored.active_account_id
}

// ── Status indicator ───────────────────────────────────────────────────────

async function refreshStatus() {
  try {
    const status = await chrome.runtime.sendMessage({ type: 'get_status' })
    if (status?.connected) {
      $statusDot.className = 'status-dot status-connected'
      $statusText.textContent = 'Conectado'
      $disconnect.style.display = ''
      $connect.textContent = 'Reconectar'
    } else if (status?.reconnectAttempts > 0) {
      $statusDot.className = 'status-dot status-connecting'
      $statusText.textContent = `Reconectando… (intento ${status.reconnectAttempts})`
      $disconnect.style.display = 'none'
    } else {
      $statusDot.className = 'status-dot status-disconnected'
      $statusText.textContent = 'Sin conectar'
      $disconnect.style.display = 'none'
    }
  } catch (err) {
    $statusText.textContent = 'SW no responde — recarga extension'
  }
}

// ── Acciones ──────────────────────────────────────────────────────────────

$connect.addEventListener('click', async () => {
  const orionUrl = $url.value.trim().replace(/\/+$/, '')  // strip trailing slash
  const apiKey   = $apiKey.value.trim()
  const account  = $account.value.trim()

  if (!orionUrl || !apiKey || !account) {
    alert('Llena los 3 campos: URL, API Key, Cuenta')
    return
  }

  await chrome.storage.local.set({
    [STORAGE_KEYS.ORION_URL]:  orionUrl,
    [STORAGE_KEYS.API_KEY]:    apiKey,
    [STORAGE_KEYS.ACTIVE_ACCOUNT_ID]: account,
  })

  // Trigger reconnect en background
  await chrome.runtime.sendMessage({ type: 'reconnect' })
  setTimeout(refreshStatus, 500)
})

$disconnect.addEventListener('click', async () => {
  await chrome.runtime.sendMessage({ type: 'disconnect' })
  setTimeout(refreshStatus, 300)
})

// ── Init ────────────────────────────────────────────────────────────────

loadStored().then(refreshStatus)
setInterval(refreshStatus, 2_000)
